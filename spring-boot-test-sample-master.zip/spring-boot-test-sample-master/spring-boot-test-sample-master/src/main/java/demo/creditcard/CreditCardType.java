package demo.creditcard;

public enum CreditCardType {
    VISA,
    MASTERCARD,
    AMERICAN_EXPRESS
}
